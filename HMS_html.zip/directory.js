function a()
{
alert("!!! CANT'T CONNECT AT THE MOMENT !!!");
}

function b()
{
alert("LINE BUSY...TRY AGAIN LATER");
}